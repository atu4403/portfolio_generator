# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['portfolio_generator']

package_data = \
{'': ['*']}

install_requires = \
['Cerberus>=1.3.4,<2.0.0',
 'Jinja2>=3.0.3,<4.0.0',
 'PyYAML>=6.0,<7.0',
 'adash>=1.2.0,<2.0.0',
 'arrow>=1.2.1,<2.0.0',
 'click>=8.0.3,<9.0.0',
 'feedparser>=6.0.8,<7.0.0',
 'requests>=2.26.0,<3.0.0',
 'xmltodict>=0.12.0,<0.13.0']

entry_points = \
{'console_scripts': ['pfg = portfolio_generator.cli:main']}

setup_kwargs = {
    'name': 'portfolio-generator',
    'version': '0.3.0',
    'description': '',
    'long_description': '[comment]: <> (description)\n\n[![Test](https://github.com/atu4403/portfolio_generator/actions/workflows/test.yml/badge.svg)](https://github.com/atu4403/portfolio_generator/actions/workflows/test.yml)\n\n[![PyPI version](https://badge.fury.io/py/portfolio_generator.svg)](https://badge.fury.io/py/portfolio_generator)\n\n[comment]: <> (document link)\n\n## Install\n\n```bash\npip install portfolio_generator\n```\n\n## Useit\n',
    'author': 'atu4403 ',
    'author_email': '73111778+atu4403@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/atu4403',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
