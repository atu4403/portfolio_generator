[comment]: <> (description)

[![Test](https://github.com/atu4403/portfolio_generator/actions/workflows/test.yml/badge.svg)](https://github.com/atu4403/portfolio_generator/actions/workflows/test.yml)

[![PyPI version](https://badge.fury.io/py/portfolio_generator.svg)](https://badge.fury.io/py/portfolio_generator)

[comment]: <> (document link)

## Install

```bash
pip install portfolio_generator
```

## Useit
